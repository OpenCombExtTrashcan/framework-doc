<?php
use jc\db\DB;
use jc\mvc\model\db\Model ;
use jc\system\Application;

require 'inc.common.php' ;

// 用一个ORM数组来配置数据表和数据表之间的关系
$arrOrmConfig = array(

	'table' => 'categories' ,
	'keys' => 'cid' ,				// 主键值（可省略）

	// 定义这个数据表所拥有的 hasMany 关联
	'hasMany' => array(

		array(
			'prop' => 'books' ,		// book 对象在 category 对象内的属性名称
			'fromk' => 'cid' ,		// 外键一端的字段（可省略，默认使用数据表的主键）
			'tok' => 'category' ,	// 关键另一端的字段

			// 被关联的数据表原型
			'prototype' => array(

				'table' => 'books' ,
				'keys' => 'bid' ,		// 主键值（可省略）

				// books 表的“多对多”关联表
				'hasAndBelongsToMany' => array(
									array(
						'prop' => 'authors' ,
						'fromk' => 'bid' ,			// （可省略）
					
						'bridge' => 'authors' ,		// “桥接表”
						'btok' => 'bid' ,				// 桥接表上的外键（可省略）
						'bfromk' => 'uid' ,			// 桥接表上的连接另一端的外键（可省略）

						'tok' => 'uid' ,				// （可省略）
					
						// 被关联的表
						'prototype' => array(
							'table' => 'users' ,
							'keys' => 'uid' ,
						) ,
					) ,
				 ) ,
				 
				// books 表的“属于”关联表
				'belongsTo' => array(
					array(
						'prop' => 'press' ,
						'fromk' => 'press' ,
						'tok' => 'pid' ,
						
						// 被关联的表
						'prototype' => array(
							'table' => 'presses' ,
							'keys' => 'pid' ,
						) ,
					) ,
				 ) ,
				 
			) ,
		) ,
	
	) ,
) ;

// 将ORM配置做为 Model类构造函数的参数
$aCategory = new Model($arrOrmConfig) ;
$aCategory->name = 'Soft Engine' ;

// 在"Soft Engine"类别中创建一本图书 ----------------
$aBook1 = $aCategory->child('books')->createChild() ;
$aBook1->setData('name','Beautiful Architecture') ;
$aBook1->setData('isbn','978-111-21126-6') ;
$aBook1->setData('price',69.00) ;

// 设置这本书的出版社的信息
$aBook1->child('press')->name = '机械工业出版社' ;
$aBook1->child('press')->home = 'www.cmpbook.com' ;
$aBook1->child('press')->email = 'cmpbook@vip.163.com' ;
$aBook1->child('press')->country = '机械工业出版社' ;

// 创建这本书的两名作者
$aAuthor1 = $aBook1->child('authors')->createChild();
$aAuthor1->username = 'Diomidis Spinellis' ;

$aAuthor2 = $aBook1->child('authors')->createChild() ;
$aAuthor2->username = 'Georgios Gousios' ;
// 在"Soft Engine"类别中创建第二本图书 ----------------
$aBook2 = $aCategory->child('books')->createChild() ;
$aBook2->setData('name','Design Patterns: Elements of Reusable Object-Oriented Software') ;
$aBook2->setData('isbn','978-111-28350') ;
$aBook2->setData('price',69.00) ;

// 刚好它和前一本书属于同一个出版社
$aBook2->addChild( $aBook1->child('press'), 'press' ) ;

// 创建这本书的四名作者
$aAuthor3 = $aBook2->child('authors')->createChild() ;
$aAuthor3->username = 'Erich Gamma' ;

$aAuthor4 = $aBook2->child('authors')->createChild() ;
$aAuthor4->username = 'Richard Helm' ;

$aAuthor5 = $aBook2->child('authors')->createChild() ;
$aAuthor5->username = 'Ralph Johnson' ;

$aAuthor6 = $aBook2->child('authors')->createChild() ;
$aAuthor6->username = 'John Vlissides' ;


// 将类别、图书、出版社、作者，连同互相之间的关系，全部保存到数据库里 ... ...
$aCategory->save();
// done :)

$nCategoryId = $aCategory->cid ;

// 重新定义一个ORM配置数组，从图书开始不包括分类信息
$arrOrmConfig = array(

	'table' => 'books' ,

	// books 表的“多对多”关联表
	'hasAndBelongsToMany' => array(
		array(
			'prop' => 'authors' ,
			'fromk' => 'bid' ,
			'tok' => 'uid' ,
		
			'bridge' => 'authors' ,		// “桥接表”
			'bfromk' => 'uid',
			'btok' => 'bid',

			// 被关联的表
			'prototype' => array(
				'table' => 'users' ,
			) ,
		) ,
	 ) ,
	 
	// books 表的“属于”关联表
	'belongsTo' => array(
		array(
			'prop' => 'press' ,
			'fromk' => 'press' ,
			'tok' => 'pid' ,
			
			// 被关联的表
			'prototype' => array(
				'table' => 'presses' ,
			) ,
		) ,
	 ) ,
) ;

// Model构造函数的第二个参数为true，表示该Model 是一个聚合模型——它是多个book模型的集合
$aBookList =new Model($arrOrmConfig,true) ;

if( !$aBookList->load($nCategoryId,'category') )
{	
	Application::singleton()->response()->output("图书列表信息查询失败！") ;
}

// 遍历"集合"中的 book模型对象
foreach( $aBookList->childIterator() as $aBook )
{
	Application::singleton()->response()->output("Book Name: 《". $aBook->name . "》") ;
	Application::singleton()->response()->output("Book Press: ". $aBook->child('press')->name ) ;
	
	$arrAuthorName = array();
	foreach ( $aBook->child('authors')->childIterator() as $aAuthor ){
		$arrAuthorName[] = $aAuthor->username ;
	}
	Application::singleton()->response()->output("Book Authors: ". implode( ' , ' ,$arrAuthorName ) ) ;
	
	Application::singleton()->response()->output("Book Price: ". $aBook->price) ;
	Application::singleton()->response()->output("Book ISBN: " . $aBook->isbn ) ;
	Application::singleton()->response()->output("<hr />" ) ;
}
?>
