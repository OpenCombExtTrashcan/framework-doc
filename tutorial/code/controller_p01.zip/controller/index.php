<?php

//初始化Jecat
$aApp = require_once dirname ( __DIR__ ) . '/controller/inc.common.php';

//url简写
//$aApp->accessRouter()->addController("ctest\\controller\\ControllerA" , 'cA');
//$aApp->accessRouter()->addController("ctest\\controller\\ControllerB" , 'cB');
//$aApp->accessRouter()->addController("ctest\\controller\\ControllerC" , 'cC');

//注册package
$aApp->classLoader()->addPackage("ctest" , "/class" , null );

//自动实例化controller相应页面请求
$aController = $aApp->accessRouter()->createRequestController($aApp->request()) ;

//运行controller
$aController->mainRun();

?>