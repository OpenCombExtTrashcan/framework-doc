<?php
namespace ctest\controller;

use jc\mvc\controller\Controller;
use jc\mvc\view\View;

class ControllerC extends Controller{
	protected function init() {
		$this->createView( "vC" , "vC.html" );
	}
	
	public function process(){
		
	}
}
?>