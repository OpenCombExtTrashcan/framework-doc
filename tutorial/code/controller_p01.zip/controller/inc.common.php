<?php
namespace jc\ctest ;

// 初始化 jcat 框架
use jc\session\OriginalSession;
use jc\ui\xhtml\UIFactory ;
use jc\system\ApplicationFactory;
use jc\mvc\model\db\orm\PrototypeAssociationMap ;

include __DIR__."/../framework/inc.entrance.php" ;

$aApp = ApplicationFactory::singleton()->create(__DIR__) ;

// UI
UIFactory::singleton()->sourceFileManager()->addFolder($aApp->fileSystem ()->findFolder('/template/') ) ;

return $aApp ;
?>
