<?php
namespace jc\user\RegisterController;

use jc\mvc\model\db\Model;
use jc\mvc\view\widget\Text;
use jc\mvc\controller\Controller;
use jc\mvc\view\View;

$aApp = require_once dirname ( __DIR__ ) . '/user/inc.common.php';

class RegisterController extends Controller {
	protected function init() {
		$this->createFormView( "Register" );

		$username = new Text ( 'username', '用户名', '', TEXT::single );
		$this->viewRegister->addWidget ( $username );
	}
	
	public function process() {
		
	}
}

$aController = new RegisterController($aApp->request () );
$aController->mainRun ( );

?>