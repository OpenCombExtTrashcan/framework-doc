<?php
namespace jc\user ;

// 初始化 jcat 框架
use jc\session\OriginalSession;
use jc\session\Session;
use jc\db\DB;
use jc\db\driver\PDODriver;
use jc\ui\xhtml\UIFactory ;
use jc\system\ApplicationFactory;

include __DIR__."/../framework/inc.entrance.php" ;

$aApp = ApplicationFactory::singleton()->create(__DIR__) ;

// UI
UIFactory::singleton()->sourceFileManager()->addFolder(__DIR__.'/templates') ;

// 会话
$aSession = new OriginalSession() ;
$aSession->start() ;
Session::setSingleton($aSession) ;

return $aApp ;
?>
