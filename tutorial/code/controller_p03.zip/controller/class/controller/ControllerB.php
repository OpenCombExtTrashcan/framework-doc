<?php
namespace ctest\controller;

use jc\mvc\controller\Controller;
use jc\mvc\view\View;

class ControllerB extends Controller{
	protected function init() {
		$this->createView( "viewB" , "viewB.html" );
	}
	
	public function process(){
		
	}
}
?>