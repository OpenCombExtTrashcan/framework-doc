<?php
namespace ctest\controller;

use jc\mvc\controller\Controller;
use jc\mvc\view\View;

class ControllerA extends Controller{
	protected function init() {
		//让controller实例化一个带有表单的视图 , 名字是viewA, 使用的模板是viewA.html
		$this->createView( "A" , "viewA.html" );
		
		//让controller通过book数据表原型创建数据模型
		$this->createModel( 'book' , array() , true);
		$this->viewA->setModel($this->modelBook);
		
		//无条件的读取所有book模型中的数据
		$this->modelBook->load();
		
		//把数据模型中的数据整理成数组
		$arrBooks = array();
		foreach ($this->modelBook->childIterator() as $key => $aBook){
			$arrBooks[] = $aBook;
		}
		
		//把整理好的数组发送给模板用于遍历
		$this->viewA->variables()->set('arrBooks',$arrBooks) ;
	}
	
	public function process(){
		
	}
}
?>