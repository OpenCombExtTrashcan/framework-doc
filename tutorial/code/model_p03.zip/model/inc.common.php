<?php
use jc\db\DB;
use jc\db\driver\PDODriver;

use jc\system\ApplicationFactory ;

// 加载 jecat php framework
include __DIR__.'/../framework/inc.entrance.php' ;

// 用 Application工厂类的单件实例创建一个 Application 对象
$aApp = ApplicationFactory::singleton()->create(__DIR__) ;

// 连接到数据库
DB::singleton()->setDriver( new PDODriver("mysql:host=localhost;dbname=jc-example",'root','123456',array(\PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'")) ) ;
?>