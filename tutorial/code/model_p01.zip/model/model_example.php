<?php
use jc\mvc\model\db\Model ;
use jc\system\Application;

require 'inc.common.php' ;

// 为 categories 表创建一个Modol 对象，参数是数据表的表名
$aCategory = new Model('categories') ;

// 设置分类的名称
$aCategory->setData('name','Soft Engine') ;

// 保存到数据库
if( $aCategory->save() )
{
	Application::singleton()->response()->output("图书分类保存成功！") ;
}
else
{
	Application::singleton()->response()->output("图书分类保存失败！") ;
}


// 为 categories 表创建一个Modol 对象，参数是数据表的表名
$aBook = new Model('books') ;

// 设置分类的名称
$aBook->setData('category',$aCategory->data('cid')) ;
$aBook->setData('name','Beautiful Architecture') ;
$aBook->setData('isbn','978-111-21126-6') ;
$aBook->setData('price',69.00) ;

// 保存到数据库
if( $aBook->save() )
{
	Application::singleton()->response()->output("图书保存成功！") ;
}
else
{
	Application::singleton()->response()->output("图书保存失败！") ;
}

//获得刚刚添加的图书类型的ID
$nCId = $aCategory->cid ;

// 删除前面创建的 $aCategory 和 $aBook
unset($aCategory) ;
unset($aBook) ;

$aCategory = new Model('categories') ;
$aBook = new Model('books') ;

// 查找主键 cid 为$nCId的 categories表中的记录
if( !$aCategory->load($nCId) )
{
	Application::singleton()->response()->output("无法找到指定的图书分类") ;
}

// 查找 name 字段 为"Beautiful Architecture"的 books表中的记录
if( !$aBook->load('Beautiful Architecture','name') )
{
	Application::singleton()->response()->output("无法找到指定的图书") ;
}

Application::singleton()->response()->output("category name: {$aCategory->name}") ;
Application::singleton()->response()->output("book name: {$aBook->name}") ;

//修改书的信息
$aBook->name = "Design Patterns: Elements of Reusable Object-Oriented Software" ;
$aBook->setData('isbn','978-111-28350') ;

// 将改动保存到数据库
if( $aBook->save() )
{
	Application::singleton()->response()->output("图书信息修改成功！") ;
}
else
{
	Application::singleton()->response()->output("图书信息修改失败！") ;
}


// 从数据表中删除图书分类
if( $aCategory->delete() )
{
	Application::singleton()->response()->output("图书分类删除成功！") ;
}
else
{
	Application::singleton()->response()->output("图书分类删除失败！") ;
}

// 从数据表中删除图书
if( $aBook->delete() )
{	
	Application::singleton()->response()->output("图书信息删除成功！") ;
}
else
{
	Application::singleton()->response()->output("图书信息删除失败！") ;
}
?>
