<?php
use jc\mvc\view\FormView;
use jc\mvc\view\View;
use jc\mvc\model\db\Model;
use jc\mvc\view\widget\Text;
use jc\mvc\view\widget\Select;
use jc\mvc\view\DataExchanger;
use jc\auth\IdManager;
use jc\db\DB;
use jc\util\DataSrc;

//初始化Jecat
$aApp = require_once dirname ( __DIR__ ) . '/de/inc.common.php';

//创建一个View对象,用来显示页面内容
$aView = new FormView( 'de' ,'de.html');

/**************        加载数据模型        **************/

//读取数据
$aBook = Model::fromFragment('book',array('press' ) );
//这里只是实验,我们直接读取其中一条记录
$aBook->load(1);
//把数据库模型和视图关联
$aView->setModel($aBook);

//加载图书分类模型
$aCat = Model::fromFragment('category' ,array(), true);
$aCat->load();

$aPress = new Model('presses',true);
$aPress->load();

/**************        加载视图控件        **************/

//书名控件
$aBookName = new Text( 'bookName','书名','',Text::single );
$aView->addWidget($aBookName , 'name');

//图书分类控件,已经其中的option
$arrCatOptions = array(array('请选择分类...', 0 , false));
foreach( $aCat->childIterator() as $aSingleCat)
{
	$arrAOption = array($aSingleCat->name,$aSingleCat->cid,false);
	array_push($arrCatOptions, $arrAOption);
}
$aBookCat = new Select ( 'bookCat', '分类' );
$aBookCat->addOptionByArray($arrCatOptions);
$aBookCat->setValue($aBook->category);
$aView->addWidget($aBookCat , 'category');

$arrPressOptions = array(array('请选择分类...', 0 , false));
foreach( $aPress->childIterator() as $aSinglePress)
{
	$arrAOption = array($aSinglePress->name,$aSinglePress->pid,false);
	array_push($arrPressOptions, $arrAOption);
}
$aBookPress = new Select ( 'bookPress', '出版社' );
$aBookPress->addOptionByArray($arrPressOptions);
$aBookPress->setValue($aBook->press);
$aView->addWidget($aBookPress , 'press');

$aBookPrice = new Text( 'bookPrice','价格','',Text::single );
$aView->addWidget($aBookPrice , 'price');

/**************        处理页面请求        **************/

//获取post ,get 等方式传来的信息
$aPar = $aApp->request();
//判断是否是页面提交请求
if( $aView->isSubmit( $aPar ) ){
	$aView->loadWidgets ( $aPar );
	
	$aOutputStream = $aView->outputStream();
	
	//看看模型中的数据发生了什么变化
	$aOutputStream->write( '数据交换,模型到控件方向' . '<br />') ;
	$aOutputStream->write( '<hr />' ) ;
	$aOutputStream->write( '交换前 :' . '<br />') ;
	$aOutputStream->write('name列的值为: ' . $aBook->data('name')  . '<br />') ;
	$aOutputStream->write('category列的值为: ' . $aBook->data('category')  . '<br />') ;
	$aOutputStream->write('press列的值为: ' . $aBook->data('press')  . '<br />') ;
	$aOutputStream->write('price列的值为: ' . $aBook->data('price')  . '<br />') ;
	$aOutputStream->write('isbn列的值为: ' . $aBook->data('isbn')  . '<br />') ;
	
	//数据交换,把控件中的数据交给模型
	$aView->exchangeData ( DataExchanger::WIDGET_TO_MODEL );
	
	$aOutputStream->write( '交换后 :'  . '<br />') ;
	$aOutputStream->write('name列的值为: ' . $aBook->data('name')  . '<br />') ;
	$aOutputStream->write('category列的值为: ' . $aBook->data('category')  . '<br />') ;
	$aOutputStream->write('press列的值为: ' . $aBook->data('press')  . '<br />') ;
	$aOutputStream->write('price列的值为: ' . $aBook->data('price')  . '<br />') ;
	$aOutputStream->write('isbn列的值为: ' . $aBook->data('isbn')  . '<br />') ;
	$aOutputStream->write( '<hr />' ) ;
	//将模型中的数据保存到数据库
	if($aBook->save()){
		$aApp->response()->output('图书信息保存成功') ;
	}else{
		$aApp->response()->output('图书信息保存失败') ;
	}
	
}else{
	$aOutputStream = $aView->outputStream();
	
	$aOutputStream->write( '数据交换,模型到控件方向' . '<br />') ;
	$aOutputStream->write( '<hr />' ) ; 
	$aOutputStream->write( '交换前 :'  . '<br />') ;
	$aOutputStream->write('name列的值为: ' . $aBook->data('name')  . '<br />') ;
	$aOutputStream->write('category列的值为: ' . $aBook->data('category')  . '<br />') ;
	$aOutputStream->write('press列的值为: ' . $aBook->data('press')  . '<br />') ;
	$aOutputStream->write('price列的值为: ' . $aBook->data('price')  . '<br />') ;
	$aOutputStream->write('isbn列的值为: ' . $aBook->data('isbn')  . '<br />') ;
	
	$aView->exchangeData ( DataExchanger::MODEL_TO_WIDGET );
	
	$aOutputStream->write( '交换后 :'  . '<br />') ;
	$aOutputStream->write('name列的值为: ' . $aBook->data('name')  . '<br />') ;
	$aOutputStream->write('category列的值为: ' . $aBook->data('category')  . '<br />') ;
	$aOutputStream->write('press列的值为: ' . $aBook->data('press')  . '<br />') ;
	$aOutputStream->write('price列的值为: ' . $aBook->data('price')  . '<br />') ;
	$aOutputStream->write('isbn列的值为: ' . $aBook->data('isbn')  . '<br />') ;
	$aOutputStream->write( '<hr />' ) ;
}

$aView->show();
?>