<?php
namespace jc\user ;

// 初始化 jcat 框架
use jc\session\OriginalSession;
use jc\session\Session;
use jc\db\DB;
use jc\db\driver\PDODriver;
use jc\ui\xhtml\UIFactory ;
use jc\system\ApplicationFactory;
use jc\mvc\model\db\orm\PrototypeAssociationMap ;

include __DIR__."/../framework/inc.entrance.php" ;

$aApp = ApplicationFactory::singleton()->create(__DIR__) ;

// UI
UIFactory::singleton()->sourceFileManager()->addFolder($aApp->fileSystem ()->findFolder('/template/') ) ;

//链接数据库
DB::singleton()->setDriver( new PDODriver("mysql:host=localhost;dbname=dataexchange",'root','123456') ) ;

//数据库关系
$aPam = PrototypeAssociationMap::singleton() ;

// 定义 categories 数据表原型
$aPam->addOrm(
	array(
		'name' => 'category' ,			// 数据表原型名称
		'table' => 'categories' ,		// 数据表名称
		
		// 定义这个数据表所拥有的 hasMany 关联
		'hasMany' => array(
			array(
				'prop' => 'books' ,		// book 对象在 category 对象内的属性名称
				'fromk' => 'cid',
				'tok' => 'category' ,	// 关键另一端的字段
				
				// 被关联的数据表原型
				'prototype' => 'book' ,	// books 表的原型名称
			) ,
		) ,
	)
) ;

// 定义 books 数据表原型
$aPam->addOrm(
	array(
		'name' => 'book' ,				// 数据表原型名称
		'table' => 'books' ,			// 数据表名称
	
		// 定义这个数据表所拥有的 hasMany 关联
		'belongsTo' => array(
			array(
				'prop' => 'press' ,
				'fromk' => 'press' ,	// 外键的字段名
				'tok' => 'pid' ,	// 关键另一端的字段
				// 被关联的表
				'prototype' => 'press' ,// 为 presses 表定义的原型名称
			) ,
		) ,
		
		// 定义这个数据表所拥有的 hasMany 关联
		'hasAndBelongsToMany' => array(
			array(
				'prop' => 'authors' ,
				'fromk' => 'bid' ,
				'bridge' => 'authors' ,		// “桥接表”
				'btok' => 'bid' ,				// 桥接表上的外键（可省略）
				'bfromk' => 'uid' ,			// 桥接表上的连接另一端的外键（可省略）
				'tok' => 'uid' ,
				// 被关联的表
				'prototype' => 'user' ,
			),
		) ,
	)
) ;

// 定义 presses 数据表原型
$aPam->addOrm(
	array(
		'name' => 'press' ,			// 数据表原型名称
		'table' => 'presses' ,		// 数据表名称
	)
) ;

// 定义 categories 数据表原型
$aPam->addOrm(
	array(
		'name' => 'user' ,			// 数据表原型名称
		'table' => 'users' ,		// 数据表名称
	)
) ;


return $aApp ;
?>
