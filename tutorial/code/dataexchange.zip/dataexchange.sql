-- phpMyAdmin SQL Dump
-- version 3.4.3.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2011 年 08 月 25 日 11:51
-- 服务器版本: 5.1.54
-- PHP 版本: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dataexchange`
--

-- --------------------------------------------------------

--
-- 表的结构 `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `uid` int(10) NOT NULL,
  `bid` int(8) NOT NULL,
  UNIQUE KEY `uid` (`uid`,`bid`),
  UNIQUE KEY `bid` (`bid`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `bid` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `category` int(6) NOT NULL,
  `press` int(10) NOT NULL,
  `price` float NOT NULL,
  `isbn` varchar(40) NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `category` (`category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `books`
--

INSERT INTO `books` (`bid`, `name`, `category`, `press`, `price`, `isbn`) VALUES
(1, 'Beautiful A', 1, 1, 169, '978-111-21126-6'),
(2, 'Design Patterns: Elements of Reusable Object-Oriented Software', 1, 1, 69, '978-111-28350');

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cid` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`cid`, `name`) VALUES
(1, 'Soft Engine'),
(2, 'Search Engine'),
(3, 'Database');

-- --------------------------------------------------------

--
-- 表的结构 `presses`
--

CREATE TABLE IF NOT EXISTS `presses` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(90) NOT NULL,
  `home` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `country` varchar(30) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `presses`
--

INSERT INTO `presses` (`pid`, `name`, `home`, `email`, `country`) VALUES
(1, 'Apress', 'English', 'XXX@email.com', 'English'),
(2, 'O''REILLY', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `passwd` varchar(16) NOT NULL,
  `group` int(4) NOT NULL,
  `lastLoginTime` int(10) DEFAULT NULL,
  `createTime` int(10) DEFAULT NULL,
  `updateTime` int(10) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
