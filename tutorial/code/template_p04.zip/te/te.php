<?php

use jc\ui\xhtml\UIFactory ;
use jc\system\ApplicationFactory;

// 初始化 jcat 框架
include __DIR__."/../framework/inc.entrance.php" ;

$aApp = ApplicationFactory::singleton()->create(__DIR__) ;

// 加载模板
UIFactory::singleton()->sourceFileManager()->addFolder( $aApp->fileSystem ()->findFolder('/template/')) ;

// 创建一个 UI 对象
$aUI = UIFactory::singleton()->create() ;

// 设置可以在模板文件里使用的变量
$aUI->variables()->set('bTrue' , false) ;

// 添加一个数组变量给模板
$aUI->variables()->set('arrBooks' , array(
		'数据结构' => '26.00' ,
        '毛泽东传' => '55.00' ,
        '万物简史' => '36.00' ,)) ;

$aUI->variables()->set('sWhatIsThis' ,'Jecat') ;

// 渲染并向浏览器显示一个模板文件
$aUI->display('template.html');
?>
