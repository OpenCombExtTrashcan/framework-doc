<?php
namespace ctest\controller;

use jc\mvc\controller\Controller;
use jc\mvc\view\View;

class ControllerA extends Controller{
	protected function init() {
		$this->createView( "viewA" , "viewA.html" );
	}
	
	public function process(){
		
	}
}
?>