<?php
namespace jc\user\RegisterController;

use jc\mvc\model\db\Model;
use jc\mvc\view\widget\Text;
use jc\mvc\view\widget\Group;
use jc\mvc\view\widget\CheckBtn;
use jc\mvc\view\widget\Select;
use jc\mvc\view\widget\SelectList;
use jc\mvc\view\widget\File;
use jc\mvc\controller\Controller;
use jc\mvc\view\View;

$aApp = require_once dirname ( __DIR__ ) . '/user/inc.common.php';

class RegisterController extends Controller {
	protected function init() {
		$this->createFormView ( "Register" );
		
		$username = new Text ( 'username', '用户名', '', TEXT::single );
		$this->viewRegister->addWidget ( $username );
		
		$password1 = new Text ( 'password1', '确认密码1', '', Text::password );
		$this->viewRegister->addWidget ( $password1 );
		
		$password2 = new Text ( 'password2', '确认密码2', '', Text::password );
		$this->viewRegister->addWidget ( $password2 );
		
		$group = new Group ( 'passwordGroup', '密码核对' );
		$group->addWidget ( $password1 );
		$group->addWidget ( $password2 );
		$this->viewRegister->addWidget ( $group );
		
		$email = new Text ( 'email', '邮件' );
		$this->viewRegister->addWidget ( $email );
		
		$ademail = new CheckBtn ( 'ademail', '接受广告邮件', 'ademail', CheckBtn::checkbox );
		$this->viewRegister->addWidget ( $ademail );
		
		$selectprovince = new Select ( 'selectprovince', '选择省' );
		$selectprovince->addOption ( '请选择...', 0, true );
		$selectprovince->addOption ( '辽宁', 'liaoning', false );
		$selectprovince->addOption ( '北京', 'beijing', false );
		$this->viewRegister->addWidget ( $selectprovince );
		
		$selectcity = new SelectList ( 'selectcity', '选择城市', 5, true );
		$selectcity->addOptionByArray ( array (
												array ('沈阳', 'shenyang', false ),
												array ('大连', 'dalian', false ), 
												array ('锦州', 'jinzhou', true ) 
												));
		$this->viewRegister->addWidget ( $selectcity );
		
		if(!$uploadForlder = $this->application ()->fileSystem ()->findFolder ( '/data/widget' )){
			$uploadForlder = $this->application ()->fileSystem ()->createFolder ( '/data/widget');
		}
		$fileupload = new File ( 'fileupload', '文件上传', $uploadForlder );
		$this->viewRegister->addWidget ( $fileupload );
	}
	
	public function process() {
		if ($this->viewRegister->isSubmit ( $this->aParams )) {
			$this->viewRegister->loadWidgets ( $this->aParams );
			$this->response ()->output ( $this->aParams->get ( 'username' ) );
			$this->response ()->output ( var_export ( $this->viewRegister->widget ( 'passwordGroup' )->value () ,true) );
			$this->response()->output($this->aParams->get('email')) ;
			$this->response()->output($this->aParams->get('ademail')) ;
			$this->response()->output($this->aParams->get('selectprovince')) ;
			$this->response()->output(var_export($this->aParams->get('selectcity'),true)) ;
		}
	}
}

$aController = new RegisterController ( $aApp->request () );
$aController->mainRun ();

?>
